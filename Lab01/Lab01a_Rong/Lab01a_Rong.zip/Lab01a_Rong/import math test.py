# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# 
# Name: 		Rong Xu
# Section:		554
# Assignment:	Lab 1a
# Date:		31/08/2019
from math import *
print(cos(0))
print(sin(0))