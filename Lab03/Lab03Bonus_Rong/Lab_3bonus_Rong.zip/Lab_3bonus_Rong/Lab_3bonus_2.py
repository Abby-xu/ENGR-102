#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# By submitting this assignment, I agree to the following:
# Name:         RongXu
# Section:	554
# Assignment:	Lab 3bonus
# Date:		12/09/2019

from math import*
a=sin(1)/1
print("the result of function is",str(a)[0:10])
a=sin(0.1)/0.1
print("the result of function is",str(a)[0:10])
a=sin(0.01)/0.01
print("the result of function is",str(a)[0:10])
a=sin(0.001)/0.001
print("the result of function is",str(a)[0:10])
a=sin(0.0001)/0.0001
print("the result of function is",str(a)[0:10])
a=sin(0.00001)/0.00001
print("the result of function is",str(a)[0:10])
a=sin(0.000001)/0.000001
print("the result of function is",str(a)[0:10])