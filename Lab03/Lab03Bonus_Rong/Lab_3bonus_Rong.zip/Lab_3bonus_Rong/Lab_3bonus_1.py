#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# By submitting this assignment, I agree to the following:
# Name:         RongXu
# Section:	554
# Assignment:	Lab 3bonus
# Date:		07/09/2019
# 

a=int(input("input the number of digits that you want:"))
x=1/7
print(str(x)[0:a+2])