# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name:         Esther Li 828007859
#               Dacheng Jiang 428007586
#               Rong Xu 928009312
#
# Section:		ENGR 102 554
# Assignment:	Lab 03 A
# Date:		10 September 2019

from math import *
a = float(input ("Enter the number of pascal: "))
print("The number of the millimeter of mercury: "+str(a*0.00750062))