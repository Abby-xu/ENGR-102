# -*- coding: utf-8 -*-
"""
Dacheng Jiang UIN: 428007586
section: 554
Assighment: Lab_3B
Date: 01/14/2019
"""
from math import*


a = input("please enter your name")
b = input("please enter your birthday")

print(a)
print(b)


