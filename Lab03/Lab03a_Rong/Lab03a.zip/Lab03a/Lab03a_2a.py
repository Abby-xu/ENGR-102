# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name:         Rong Xu 928009312(pair's work)
# Section:		ENGR 102 554
# Assignment:	Lab 03 A
# Date:		10 September 2019
a1=str(input("please input 1st person's name:"))
b1=int(input("please input 1st person's birthday with only the numbers(yyyymmdd):"))
a2=str(input("please input 2nd person's name:"))
b2=int(input("please input 2nd person's birthday with only the numbers(yyyymmdd):"))
a3=str(input("please input 3rd person's name:"))
b3=int(input("please input 3rd person's birthday with only the numbers(yyyymmdd):"))
a4=str(input("please input 4th person's name:"))
b4=int(input("please input 4th person's birthday with only the numbers(yyyymmdd):"))
print(a1,"'s birthday is:",str(b1)[0:4],"/",str(b1)[4:6],"/",str(b1)[6:8])
print(a2,"'s birthday is:",str(b2)[0:4],"/",str(b3)[4:6],"/",str(b2)[6:8])
print(a3,"'s birthday is:",str(b3)[0:4],"/",str(b3)[4:6],"/",str(b3)[6:8])
print(a4,"'s birthday is:",str(b4)[0:4],"/",str(b4)[4:6],"/",str(b4)[6:8])