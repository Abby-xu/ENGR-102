# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name:         Esther Li 828007859
#               Dacheng Jiang 428007586(Pair's work)
#      
#
# Section:		ENGR 102 554
# Assignment:	Lab 03 A
# Date:		10 September 2019

a1=str(input("please input 1st student's name:"))
b1=str(input("please input 1st student's birthday like(yyyy/mm/dd):"))

a2=str(input("please input 2nd student's name:"))
b2=str(input("please input 2nd student's birthday like(yyyy/mm/dd):"))

a3=str(input("please input 3rd student's name:"))
b3=str(input("please input 3rd student's birthday like(yyyy/mm/dd):"))

a4=str(input("please input 4th student's name:"))
b4=str(input("please input 4th student's birthday like(yyyy/mm/dd):"))

print(a1,"'s birthday is:",b1)
print(a2,"'s birthday is:",b2)
print(a3,"'s birthday is:",b3)
print(a4,"'s birthday is:",b4)